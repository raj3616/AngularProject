export interface SlideInterface {
  url: string;
  title: string;
}
